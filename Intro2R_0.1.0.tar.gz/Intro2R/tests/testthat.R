library(testthat)
library(Intro2R)

test_check("Intro2R")
